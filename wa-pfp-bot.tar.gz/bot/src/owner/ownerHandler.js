const { User, Session, AutoChangeJob, SupportTicket, ForceJoin } = require('../database/models');
const K = require('../handlers/keyboards');
const { setState, clearState } = require('../middleware/session');
const { chunkArray } = require('../utils/helpers');
const logger = require('../utils/logger');

async function panel(ctx) {
  await ctx.editMessageText('👑 *Owner Control Panel*\n\nWhat would you like to manage?',
    { parse_mode: 'Markdown', reply_markup: K.ownerPanel() })
    .catch(() => ctx.reply('Owner Panel:', { reply_markup: K.ownerPanel() }));
}

async function stats(ctx) {
  const [users, activeSessions, allSessions, activeJobs, openTickets] = await Promise.all([
    User.countDocuments(),
    Session.countDocuments({ isActive: true }),
    Session.countDocuments(),
    AutoChangeJob.countDocuments({ isActive: true }),
    SupportTicket.countDocuments({ status: 'open' }),
  ]);
  await ctx.editMessageText(
    `📊 *Bot Statistics*\n\n` +
    `👥 Total Users: *${users}*\n` +
    `📱 Total Sessions: *${allSessions}*\n` +
    `🟢 Active Sessions: *${activeSessions}*\n` +
    `🔄 Active Auto-Changes: *${activeJobs}*\n` +
    `🎫 Open Tickets: *${openTickets}*`,
    { parse_mode: 'Markdown', reply_markup: K.back('owner') }
  ).catch(() => {});
}

async function users(ctx) {
  const list = await User.find().sort({ lastActive: -1 }).limit(20);
  const lines = list.map((u, i) =>
    `${i + 1}. ${u.firstName || ''} @${u.username || '—'} (\`${u.telegramId}\`)`
  ).join('\n') || 'No users yet.';
  await ctx.editMessageText(`👥 *Users (last 20)*\n\n${lines}`,
    { parse_mode: 'Markdown', reply_markup: K.back('owner') }).catch(() => {});
}

async function broadcastPrompt(ctx) {
  ctx.setState({ step: 'broadcast' });
  await ctx.editMessageText(
    '📢 *Broadcast*\n\nSend the message to broadcast (text, photo, video, or document):',
    { parse_mode: 'Markdown', reply_markup: K.back('owner') }
  ).catch(() => ctx.reply('Send broadcast message:'));
}

async function broadcastDo(ctx, bot) {
  clearState(ctx.from.id);
  const all = await User.find({ isBlocked: false });
  const m   = await ctx.reply(`📢 Broadcasting to ${all.length} users...`);

  let ok = 0, fail = 0;
  for (const chunk of chunkArray(all, 25)) {
    await Promise.allSettled(chunk.map(async u => {
      try {
        const tid = u.telegramId;
        if (ctx.message.text) {
          await bot.telegram.sendMessage(tid, ctx.message.text, { parse_mode: 'Markdown' });
        } else if (ctx.message.photo) {
          await bot.telegram.sendPhoto(tid, ctx.message.photo.at(-1).file_id, { caption: ctx.message.caption || '' });
        } else if (ctx.message.video) {
          await bot.telegram.sendVideo(tid, ctx.message.video.file_id, { caption: ctx.message.caption || '' });
        } else if (ctx.message.document) {
          await bot.telegram.sendDocument(tid, ctx.message.document.file_id, { caption: ctx.message.caption || '' });
        }
        ok++;
      } catch { fail++; }
    }));
    await new Promise(r => setTimeout(r, 80));
  }

  await ctx.telegram.editMessageText(ctx.chat.id, m.message_id, null,
    `✅ *Broadcast done*\n\n✅ Success: ${ok}\n❌ Failed: ${fail}`,
    { parse_mode: 'Markdown', reply_markup: K.back('owner') }
  );
}

/* ── Force Join ──────────────────────────────────────────── */
async function fjPanel(ctx) {
  const links = await ForceJoin.find();
  const btns  = links.map(l => [
    { text: `🔗 ${l.title || l.link}`, callback_data: `fj_info:${l._id}` },
    { text: '❌',                       callback_data: `fj_del:${l._id}`  },
  ]);
  if (links.length < 5) btns.push([{ text: '➕ Add Link', callback_data: 'fj_add' }]);
  btns.push([{ text: '⬅ Back', callback_data: 'owner' }]);
  await ctx.editMessageText(
    `📢 *Force Join Settings*\n${links.length}/5 links configured:`,
    { parse_mode: 'Markdown', reply_markup: { inline_keyboard: btns } }
  ).catch(() => {});
}

async function fjAddPrompt(ctx) {
  ctx.setState({ step: 'fj_add' });
  await ctx.editMessageText(
    '➕ *Add Force Join Link*\n\nSend the channel/group invite link:',
    { parse_mode: 'Markdown', reply_markup: K.back('o_fj') }
  ).catch(() => ctx.reply('Send invite link:'));
}

async function fjAddDo(ctx) {
  clearState(ctx.from.id);
  const link = ctx.message.text?.trim();
  if (!link.startsWith('http') && !link.startsWith('@'))
    return ctx.reply('❌ Invalid. Send a t.me link or @username.');
  await ForceJoin.create({ link, title: link });
  await ctx.reply('✅ Link added.', { reply_markup: K.back('o_fj') });
}

async function fjDel(ctx, id) {
  await ForceJoin.findByIdAndDelete(id);
  await ctx.answerCbQuery('✅ Removed').catch(() => {});
  await fjPanel(ctx);
}

async function restart(ctx) {
  await ctx.editMessageText('🔄 Restarting...', { parse_mode: 'Markdown' }).catch(() => {});
  logger.info('Restart requested by owner');
  setTimeout(() => process.exit(0), 500);
}

module.exports = { panel, stats, users, broadcastPrompt, broadcastDo, fjPanel, fjAddPrompt, fjAddDo, fjDel, restart };
