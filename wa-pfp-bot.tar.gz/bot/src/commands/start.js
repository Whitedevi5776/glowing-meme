const K = require('../handlers/keyboards');
const { isOwner, checkForceJoin } = require('../middleware/auth');

async function start(ctx, bot) {
  const canUse = await checkForceJoin(ctx, bot);
  if (!canUse) return;

  const name  = ctx.from?.first_name || 'User';
  const owner = isOwner(ctx.from?.id);

  await ctx.reply(
    `✨ *Welcome, ${name}!*\n\n` +
    `I'm your premium *WhatsApp Profile Picture Manager*.\n\n` +
    `🖼 Upload HD photos with *zero cropping*\n` +
    `📌 Search Pinterest for stunning images\n` +
    `🔄 Auto-rotate profile pics on a schedule\n` +
    `📱 Manage *unlimited* WhatsApp accounts\n\n` +
    `_Choose an option below to get started:_`,
    { parse_mode: 'Markdown', reply_markup: K.mainMenu(owner) }
  );
}

module.exports = { start };
