const { isOwner } = require('../middleware/auth');
const pi = require('./pinterestHandler');
const pa = require('./pairingHandler');
const ac = require('./accountHandler');
const su = require('./supportHandler');
const ow = require('../owner/ownerHandler');
const logger = require('../utils/logger');

async function route(ctx, bot) {
  const step  = ctx.userState?.step;
  const owner = isOwner(ctx.from?.id);
  if (!step) return; // no active state — ignore stray messages

  try {
    switch (step) {
      case 'pi_query':
        ctx.clearState();
        return pi.search(ctx, ctx.message.text?.trim() || '', 0);

      case 'pair_phone':
        return pa.handlePhone(ctx, ctx.message.text?.trim() || '', bot);

      case 'set_pfp':
        return ac.handlePfpImage(ctx, ctx.userState.num, bot);

      case 'auto_hour_interval':
      case 'auto_day_interval':
        return ac.handleAutoInterval(ctx);

      case 'auto_hour_images':
      case 'auto_day_images':
        return ac.handleAutoImages(ctx, bot);

      case 'support_msg':
        return su.handleMsg(ctx, bot);

      case 'owner_reply':
        if (owner) return su.ownerReplyDo(ctx, bot);
        break;

      case 'broadcast':
        if (owner) return ow.broadcastDo(ctx, bot);
        break;

      case 'fj_add':
        if (owner) return ow.fjAddDo(ctx);
        break;

      default:
        break;
    }
  } catch (err) {
    logger.error('msg router: ' + err.message);
    await ctx.reply('❌ Something went wrong. Try again.').catch(() => {});
  }
}

module.exports = { route };
