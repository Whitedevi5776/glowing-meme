const K = {
  mainMenu(owner = false) {
    const b = [
      [{ text: '📌 Pinterest Images', callback_data: 'pinterest' }],
      [{ text: '🔗 Pair WhatsApp',    callback_data: 'pair_wa'   }],
      [{ text: '📱 Paired Accounts',  callback_data: 'paired'    }],
      [{ text: '💬 Support',          callback_data: 'support'   }],
    ];
    if (owner) b.push([{ text: '👑 Owner Panel', callback_data: 'owner' }]);
    return { inline_keyboard: b };
  },

  accountMenu(num) {
    return { inline_keyboard: [
      [{ text: '🖼 Change Profile Picture',      callback_data: `set_pfp:${num}`   }],
      [{ text: '📥 Get Current Profile Picture', callback_data: `get_pfp:${num}`   }],
      [{ text: '❌ Delete Profile Picture',      callback_data: `del_pfp:${num}`   }],
      [{ text: '🔄 Auto Change Profile Picture', callback_data: `auto_pfp:${num}`  }],
      [{ text: '⛔ Stop Running Auto Change',    callback_data: `stop_auto:${num}` }],
      [{ text: '🗑 Purge Session',               callback_data: `purge:${num}`     }],
      [{ text: '⬅ Back',                         callback_data: 'paired'           }],
    ]};
  },

  afterPair(num) {
    return { inline_keyboard: [
      [{ text: '🖼 Set Profile Picture',     callback_data: `set_pfp:${num}`    }],
      [{ text: '💾 Make Session Permanent',  callback_data: `perm:${num}`       }],
      [{ text: '🗑 Delete Session',          callback_data: `purge:${num}`      }],
      [{ text: '🏠 Main Menu',               callback_data: 'main_menu'         }],
    ]};
  },

  autoMenu(num) {
    return { inline_keyboard: [
      [{ text: '⏰ Hour Based', callback_data: `auto_hour:${num}` }],
      [{ text: '📅 Day Based',  callback_data: `auto_day:${num}`  }],
      [{ text: '⬅ Back',       callback_data: `account:${num}`   }],
    ]};
  },

  pinterestBottom(q, page) {
    return { inline_keyboard: [[
      { text: '➕ View More',  callback_data: `pi_more:${page + 1}:${q}` },
      { text: '🏠 Main Menu', callback_data: 'main_menu'                 },
    ]]};
  },

  ownerPanel() {
    return { inline_keyboard: [
      [{ text: '🔄 Restart Bot',          callback_data: 'o_restart'   }],
      [{ text: '📢 Force Join Settings',  callback_data: 'o_fj'        }],
      [{ text: '💬 Broadcast Message',    callback_data: 'o_broadcast' }],
      [{ text: '📊 Statistics',           callback_data: 'o_stats'     }],
      [{ text: '👥 Users',                callback_data: 'o_users'     }],
      [{ text: '🏠 Main Menu',            callback_data: 'main_menu'   }],
    ]};
  },

  confirm(yes, no = 'main_menu') {
    return { inline_keyboard: [[
      { text: '✅ Confirm', callback_data: yes },
      { text: '❌ Cancel',  callback_data: no  },
    ]]};
  },

  back(to) { return { inline_keyboard: [[{ text: '⬅ Back', callback_data: to }]] }; },
  backMain() { return { inline_keyboard: [[{ text: '🏠 Main Menu', callback_data: 'main_menu' }]] }; },
};

module.exports = K;
