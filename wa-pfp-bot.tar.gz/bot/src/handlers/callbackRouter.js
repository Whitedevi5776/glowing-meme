const { isOwner, checkForceJoin } = require('../middleware/auth');
const K = require('./keyboards');
const pi = require('./pinterestHandler');
const pa = require('./pairingHandler');
const ac = require('./accountHandler');
const su = require('./supportHandler');
const ow = require('../owner/ownerHandler');
const logger = require('../utils/logger');

async function route(ctx, bot) {
  const data = ctx.callbackQuery?.data;
  if (!data) return;
  await ctx.answerCbQuery().catch(() => {});

  const uid   = ctx.from?.id;
  const owner = isOwner(uid);

  try {
    /* force join bypass for check & main menu */
    if (data !== 'check_join' && data !== 'main_menu') {
      if (!await checkForceJoin(ctx, bot)) return;
    }

    /* ── Navigation ── */
    if (data === 'main_menu') {
      return ctx.editMessageText('✨ *Main Menu*\n\nChoose an option:', {
        parse_mode: 'Markdown', reply_markup: K.mainMenu(owner),
      }).catch(() => ctx.reply('Main Menu:', { reply_markup: K.mainMenu(owner) }));
    }

    if (data === 'check_join') {
      if (await checkForceJoin(ctx, bot)) {
        return ctx.editMessageText('✅ *Access granted!*\n\nChoose an option:', {
          parse_mode: 'Markdown', reply_markup: K.mainMenu(owner),
        }).catch(() => ctx.reply('✅ Verified!', { reply_markup: K.mainMenu(owner) }));
      }
      return;
    }

    /* ── Pinterest ── */
    if (data === 'pinterest') return pi.start(ctx);
    if (data.startsWith('pi_more:')) {
      // format: pi_more:<page>:<query>
      const [, page, ...rest] = data.split(':');
      return pi.more(ctx, parseInt(page), rest.join(':'));
    }

    /* ── Pairing ── */
    if (data === 'pair_wa') return pa.start(ctx);

    /* ── Paired accounts ── */
    if (data === 'paired')              return ac.pairedList(ctx);
    if (data.startsWith('account:'))   return ac.accountMenu(ctx, data.slice(8));

    /* ── PFP actions ── */
    if (data.startsWith('set_pfp:'))        return ac.setPfpPrompt(ctx, data.slice(8));
    if (data.startsWith('get_pfp:'))        return ac.getPfp(ctx, data.slice(8));
    if (data.startsWith('del_pfp:'))        return ac.delPfpConfirm(ctx, data.slice(8));
    if (data.startsWith('confirm_del_pfp:')) return ac.delPfpDo(ctx, data.slice(16));

    /* ── Auto change ── */
    if (data.startsWith('auto_pfp:'))  return ac.autoMenu(ctx, data.slice(9));
    if (data.startsWith('auto_hour:')) return ac.autoHourPrompt(ctx, data.slice(10));
    if (data.startsWith('auto_day:'))  return ac.autoDayPrompt(ctx, data.slice(9));
    if (data.startsWith('stop_auto:')) return ac.stopAuto(ctx, data.slice(10));

    /* ── Purge ── */
    if (data.startsWith('purge:'))          return ac.purgeConfirm(ctx, data.slice(6));
    if (data.startsWith('confirm_purge:'))  return ac.purgeDo(ctx, data.slice(14));

    /* ── Permanent session ── */
    if (data.startsWith('perm:')) return ac.makePermanent(ctx, data.slice(5));

    /* ── Support ── */
    if (data === 'support') return su.start(ctx);
    if (data.startsWith('reply_ticket:') && owner) return su.ownerReplyPrompt(ctx, data.slice(13));
    if (data.startsWith('close_ticket:') && owner) return su.closeDo(ctx, data.slice(13));

    /* ── Owner panel ── */
    if (!owner && data.startsWith('o'))
      return ctx.answerCbQuery('⛔ Owner only.', { show_alert: true }).catch(() => {});

    if (data === 'owner')        return ow.panel(ctx);
    if (data === 'o_stats')      return ow.stats(ctx);
    if (data === 'o_users')      return ow.users(ctx);
    if (data === 'o_broadcast')  return ow.broadcastPrompt(ctx);
    if (data === 'o_restart')    return ow.restart(ctx);
    if (data === 'o_fj')         return ow.fjPanel(ctx);
    if (data === 'fj_add')       return ow.fjAddPrompt(ctx);
    if (data.startsWith('fj_del:')) return ow.fjDel(ctx, data.slice(7));

  } catch (err) {
    logger.error('cb router: ' + err.message);
    await ctx.reply('❌ Something went wrong. Please try again.').catch(() => {});
  }
}

module.exports = { route };
