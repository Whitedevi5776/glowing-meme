const QRCode = require('qrcode');
const { createWhatsAppSession } = require('../services/whatsapp');
const { Session }   = require('../database/models');
const K             = require('./keyboards');
const { setState, clearState } = require('../middleware/session');
const logger        = require('../utils/logger');

async function start(ctx) {
  ctx.setState({ step: 'pair_phone' });
  const text = '🔗 *Pair WhatsApp Account*\n\nSend your WhatsApp number with country code.\n\n_Example:_ `+1234567890`';
  await ctx.editMessageText(text, { parse_mode: 'Markdown', reply_markup: K.back('main_menu') })
    .catch(() => ctx.reply(text, { parse_mode: 'Markdown' }));
}

async function handlePhone(ctx, phone, bot) {
  const tid = String(ctx.from.id);
  const num = phone.replace(/\D/g, '');
  if (num.length < 7 || num.length > 15)
    return ctx.reply('❌ Invalid number. Include country code, e.g. `+12345678900`', { parse_mode: 'Markdown' });

  clearState(ctx.from.id);
  const wait = await ctx.reply(`📱 Connecting \`+${num}\`...`, { parse_mode: 'Markdown' });

  try {
    await createWhatsAppSession(
      tid, num,
      /* onCode */ async code => {
        await ctx.telegram.deleteMessage(ctx.chat.id, wait.message_id).catch(() => {});
        await ctx.reply(
          `🔑 *Pairing Code for \`+${num}\`:*\n\n` +
          `\`\`\`\n${code}\n\`\`\`\n\n` +
          `📲 *Steps:*\n1. Open WhatsApp\n2. Settings → Linked Devices\n3. Link a Device → Enter code\n\n⏳ Expires in 60 s`,
          { parse_mode: 'Markdown' }
        );
      },
      /* onConnected */ async sock => {
        const info = sock.user;
        await Session.findOneAndUpdate(
          { telegramId: tid, whatsappNumber: num },
          { telegramId: tid, whatsappNumber: num, isActive: true, lastConnected: new Date() },
          { upsert: true }
        );
        await ctx.reply(
          `✅ *Paired Successfully!*\n\n` +
          `📱 Number: \`+${num}\`\n` +
          `👤 Name: ${info?.name || 'Unknown'}\n\n` +
          `What would you like to do next?`,
          { parse_mode: 'Markdown', reply_markup: K.afterPair(num) }
        );
      },
      /* onDisconnected */ async (reconnect, code) => {
        if (!reconnect) {
          await ctx.reply('⚠️ Session ended — you were logged out.', { reply_markup: K.backMain() });
        }
      }
    );
  } catch (e) {
    logger.error('Pairing: ' + e.message);
    await ctx.telegram.deleteMessage(ctx.chat.id, wait.message_id).catch(() => {});
    await ctx.reply(`❌ Pairing failed: ${e.message}`, { reply_markup: K.backMain() });
  }
}

module.exports = { start, handlePhone };
