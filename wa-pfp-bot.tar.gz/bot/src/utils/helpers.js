const crypto = require('crypto');

function generateTicketId() {
  return 'TKT-' + Date.now().toString(36).toUpperCase() + '-' + crypto.randomBytes(3).toString('hex').toUpperCase();
}

function formatPhoneNumber(phone) {
  return phone.replace(/[^0-9]/g, '');
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function chunkArray(arr, size) {
  const chunks = [];
  for (let i = 0; i < arr.length; i += size) chunks.push(arr.slice(i, i + size));
  return chunks;
}

function escapeMarkdown(text) {
  return String(text).replace(/[_*[\]()~`>#+\-=|{}.!\\]/g, '\\$&');
}

function calcImageCount(mode, interval) {
  if (mode === 'hour') return Math.ceil(24 / interval);
  return Math.ceil(30 / interval);
}

module.exports = { generateTicketId, formatPhoneNumber, sleep, chunkArray, escapeMarkdown, calcImageCount };
