const fs = require('fs');
const path = require('path');
const axios = require('axios');

const DATA_DIR = path.join(process.cwd(), 'data');
const STORAGE_DIR = path.join(DATA_DIR, 'images');
const SESSIONS_DIR = path.join(DATA_DIR, 'sessions');

function ensureDir(dir) {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

ensureDir(STORAGE_DIR);
ensureDir(SESSIONS_DIR);

function getUserImageDir(telegramId, whatsappNumber) {
  const dir = path.join(STORAGE_DIR, String(telegramId), String(whatsappNumber).replace(/[^0-9]/g, ''));
  ensureDir(dir);
  return dir;
}

function getUserSessionDir(telegramId, whatsappNumber) {
  const dir = path.join(SESSIONS_DIR, String(telegramId), String(whatsappNumber).replace(/[^0-9]/g, ''));
  ensureDir(dir);
  return dir;
}

async function downloadFile(url, destPath) {
  const response = await axios.get(url, { responseType: 'arraybuffer', timeout: 30000 });
  fs.writeFileSync(destPath, response.data);
  return destPath;
}

async function downloadTelegramFile(bot, fileId, destDir, filename) {
  const file = await bot.telegram.getFile(fileId);
  const ext = path.extname(file.file_path) || '.jpg';
  const fileUrl = `https://api.telegram.org/file/bot${process.env.BOT_TOKEN}/${file.file_path}`;
  const destPath = path.join(destDir, filename + ext);
  await downloadFile(fileUrl, destPath);
  return destPath;
}

function deleteDir(dir) {
  if (fs.existsSync(dir)) fs.rmSync(dir, { recursive: true, force: true });
}

function listFiles(dir) {
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir)
    .map(f => path.join(dir, f))
    .filter(f => fs.statSync(f).isFile());
}

module.exports = { getUserImageDir, getUserSessionDir, downloadTelegramFile, downloadFile, deleteDir, listFiles };
