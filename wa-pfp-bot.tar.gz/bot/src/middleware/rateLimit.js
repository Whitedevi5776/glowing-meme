const timestamps = new Map();
const WINDOW = 1000;
const MAX = 3;

function rateLimitMiddleware() {
  return async (ctx, next) => {
    const id = ctx.from?.id;
    if (!id) return next();
    const now = Date.now();
    const ts = (timestamps.get(id) || []).filter(t => now - t < WINDOW);
    ts.push(now);
    timestamps.set(id, ts);
    if (ts.length > MAX) {
      return ctx.answerCbQuery('⚡ Slow down!', { show_alert: true }).catch(() => {});
    }
    return next();
  };
}

module.exports = { rateLimitMiddleware };
