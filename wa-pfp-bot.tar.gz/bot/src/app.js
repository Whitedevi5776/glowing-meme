require('dotenv').config();

const { Telegraf }         = require('telegraf');
const { connectDB }        = require('./database/connect');
const { sessionMiddleware } = require('./middleware/session');
const { rateLimitMiddleware } = require('./middleware/rateLimit');
const { upsertUser }       = require('./middleware/auth');
const { start: startCmd }  = require('./commands/start');
const { route: cbRoute }   = require('./handlers/callbackRouter');
const { route: msgRoute }  = require('./handlers/messageRouter');
const { startWorker, restoreJobs } = require('./schedulers/autoChange');
const logger               = require('./utils/logger');

const TOKEN = process.env.BOT_TOKEN;
if (!TOKEN) { logger.error('BOT_TOKEN missing!'); process.exit(1); }

const bot = new Telegraf(TOKEN);

async function launch() {
  /* ── Database ── */
  await connectDB();

  /* ── Global middleware ── */
  bot.use(sessionMiddleware());
  bot.use(rateLimitMiddleware());

  /* ── Commands ── */
  bot.start(async ctx => { await upsertUser(ctx); await startCmd(ctx, bot); });
  bot.help(async ctx  => {
    await ctx.reply(
      '📖 *Help*\n\n/start — Main menu\n/help — This message\n\nUse the inline buttons to navigate.',
      { parse_mode: 'Markdown' }
    );
  });

  /* ── Callbacks ── */
  bot.on('callback_query', ctx => cbRoute(ctx, bot));

  /* ── Messages ── */
  bot.on('message', async ctx => {
    await upsertUser(ctx);
    await msgRoute(ctx, bot);
  });

  /* ── Error handler ── */
  bot.catch((err, ctx) => logger.error(`[${ctx?.updateType}] ${err.message}`));

  /* ── Scheduler ── */
  try {
    await startWorker(bot);
    await restoreJobs(bot);
  } catch (e) {
    logger.warn('Scheduler unavailable (Redis not running): ' + e.message);
    logger.warn('Auto-change features will not work until Redis is started.');
  }

  /* ── Launch ── */
  await bot.launch({ dropPendingUpdates: true });
  logger.info('🤖 Bot is live!');

  process.once('SIGINT',  () => bot.stop('SIGINT'));
  process.once('SIGTERM', () => bot.stop('SIGTERM'));
}

launch().catch(err => { logger.error('Launch failed: ' + err.message); process.exit(1); });
