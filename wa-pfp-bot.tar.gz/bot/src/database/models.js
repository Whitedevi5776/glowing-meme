const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  telegramId:  { type: String, required: true, unique: true },
  username:    String,
  firstName:   String,
  lastName:    String,
  isBlocked:   { type: Boolean, default: false },
  joinedAt:    { type: Date, default: Date.now },
  lastActive:  { type: Date, default: Date.now },
});

const sessionSchema = new mongoose.Schema({
  telegramId:      { type: String, required: true },
  whatsappNumber:  { type: String, required: true },
  isActive:        { type: Boolean, default: false },
  isPermanent:     { type: Boolean, default: false },
  createdAt:       { type: Date, default: Date.now },
  lastConnected:   Date,
});
sessionSchema.index({ telegramId: 1, whatsappNumber: 1 }, { unique: true });

const autoChangeJobSchema = new mongoose.Schema({
  telegramId:      { type: String, required: true },
  whatsappNumber:  { type: String, required: true },
  mode:            { type: String, enum: ['hour', 'day'], required: true },
  interval:        { type: Number, required: true },
  images:          [{ type: String }],
  currentIndex:    { type: Number, default: 0 },
  isActive:        { type: Boolean, default: true },
  nextRun:         Date,
  bullJobId:       String,
  createdAt:       { type: Date, default: Date.now },
});
autoChangeJobSchema.index({ telegramId: 1, whatsappNumber: 1 }, { unique: true });

const supportTicketSchema = new mongoose.Schema({
  ticketId:   { type: String, required: true, unique: true },
  telegramId: { type: String, required: true },
  username:   String,
  status:     { type: String, enum: ['open', 'closed'], default: 'open' },
  messages:   [{
    from:      { type: String, enum: ['user', 'owner'] },
    text:      String,
    fileId:    String,
    fileType:  String,
    timestamp: { type: Date, default: Date.now },
  }],
  createdAt:  { type: Date, default: Date.now },
  updatedAt:  { type: Date, default: Date.now },
});

const settingsSchema = new mongoose.Schema({
  key:       { type: String, required: true, unique: true },
  value:     mongoose.Schema.Types.Mixed,
  updatedAt: { type: Date, default: Date.now },
});

const forceJoinSchema = new mongoose.Schema({
  link:      { type: String, required: true },
  chatId:    String,
  title:     String,
  type:      { type: String, enum: ['channel', 'group'], default: 'channel' },
  isActive:  { type: Boolean, default: true },
  addedAt:   { type: Date, default: Date.now },
});

const User         = mongoose.model('User', userSchema);
const Session      = mongoose.model('Session', sessionSchema);
const AutoChangeJob = mongoose.model('AutoChangeJob', autoChangeJobSchema);
const SupportTicket = mongoose.model('SupportTicket', supportTicketSchema);
const Settings     = mongoose.model('Settings', settingsSchema);
const ForceJoin    = mongoose.model('ForceJoin', forceJoinSchema);

module.exports = { User, Session, AutoChangeJob, SupportTicket, Settings, ForceJoin };
