const axios  = require('axios');
const logger = require('../utils/logger');

/* DuckDuckGo image search — no API key needed */
async function searchImages(query, page = 0) {
  try {
    const r1 = await axios.get('https://duckduckgo.com/', {
      params: { q: query, iax: 'images', ia: 'images' },
      headers: { 'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36' },
      timeout: 10000,
    });
    const match = r1.data.match(/vqd=([\d-]+)/);
    if (!match) throw new Error('No vqd token');
    const vqd = match[1];

    const r2 = await axios.get('https://duckduckgo.com/i.js', {
      params: { l: 'us-en', o: 'json', q: query, vqd, f: ',,,,,', p: '1', s: page * 10 },
      headers: { 'User-Agent': 'Mozilla/5.0', Referer: 'https://duckduckgo.com' },
      timeout: 10000,
    });

    return (r2.data?.results || []).slice(0, 10).map(r => ({
      url:   r.image,
      thumb: r.thumbnail,
      title: r.title || query,
      w: r.width,
      h: r.height,
    }));
  } catch (e) {
    logger.warn('DDG image search failed: ' + e.message);
    return searchFallback(query, page);
  }
}

/* Fallback: Pixabay-style open images via Unsplash source */
async function searchFallback(query, page = 0) {
  try {
    const r = await axios.get('https://api.unsplash.com/search/photos', {
      params: { query, per_page: 10, page: page + 1 },
      headers: { Authorization: `Client-ID DEMO` }, // replace with real key on VPS
      timeout: 8000,
    });
    return (r.data?.results || []).map(p => ({
      url:   p.urls?.full || p.urls?.regular,
      thumb: p.urls?.thumb,
      title: p.alt_description || query,
      w: p.width, h: p.height,
    }));
  } catch {
    /* last resort — return placeholder notice */
    return [];
  }
}

module.exports = { searchImages };
