const fs   = require('fs');
const { getUserSessionDir } = require('../utils/storage');
const { Session }           = require('../database/models');
const logger                = require('../utils/logger');

const active = new Map(); // key: `${tid}:${num}` → sock

/* ── resolve library ─────────────────────────────────────── */
let _lib = null;
async function lib() {
  if (_lib) return _lib;
  _lib = require('@rexxhayanasi/elaina-baileys');
  return _lib;
}

/* ── create session ──────────────────────────────────────── */
async function createWhatsAppSession(telegramId, whatsappNumber, onCode, onConnected, onDisconnected) {
  const {
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion,
  } = await lib();

  const dir = getUserSessionDir(telegramId, whatsappNumber);
  const { state, saveCreds } = await useMultiFileAuthState(dir);
  const { version }          = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    version,
    auth:  state,
    printQRInTerminal: false,
    browser: ['WAPFPManager', 'Chrome', '124.0'],
    generateHighQualityLinkPreview: false,
    logger: logger.child({ level: 'silent' }),
  });

  const key = `${telegramId}:${whatsappNumber}`;
  active.set(key, sock);
  sock.ev.on('creds.update', saveCreds);

  /* pairing code — request after 3 s so socket is ready */
  if (onCode) {
    setTimeout(async () => {
      try {
        if (!sock.authState.creds.registered) {
          const code = await sock.requestPairingCode(whatsappNumber.replace(/\D/g, ''));
          await onCode(code);
        }
      } catch (e) { logger.warn('Pairing code: ' + e.message); }
    }, 3000);
  }

  sock.ev.on('connection.update', async ({ connection, lastDisconnect }) => {
    if (connection === 'open') {
      logger.info(`WA connected: ${whatsappNumber}`);
      await Session.findOneAndUpdate(
        { telegramId: String(telegramId), whatsappNumber },
        { isActive: true, lastConnected: new Date() },
        { upsert: true }
      ).catch(() => {});
      if (onConnected) onConnected(sock);
    }
    if (connection === 'close') {
      const code       = lastDisconnect?.error?.output?.statusCode;
      const reconnect  = code !== DisconnectReason.loggedOut;
      logger.info(`WA closed: ${whatsappNumber} (${code})`);
      active.delete(key);
      await Session.findOneAndUpdate(
        { telegramId: String(telegramId), whatsappNumber },
        { isActive: false }
      ).catch(() => {});
      if (onDisconnected) onDisconnected(reconnect, code);
    }
  });

  return sock;
}

/* ── helpers ─────────────────────────────────────────────── */
function getSock(tid, num) { return active.get(`${tid}:${num}`); }

async function ensureSock(tid, num) {
  let s = getSock(tid, num);
  if (!s) s = await reconnect(tid, num);
  if (!s) throw new Error('WhatsApp not connected. Please re-pair.');
  return s;
}

async function reconnect(tid, num) {
  const session = await Session.findOne({ telegramId: String(tid), whatsappNumber: num });
  if (!session) return null;
  const dir = getUserSessionDir(tid, num);
  if (!fs.existsSync(dir) || !fs.readdirSync(dir).length) return null;

  return new Promise(res => {
    let done = false;
    const to = setTimeout(() => { if (!done) { done = true; res(null); } }, 30000);
    createWhatsAppSession(tid, num, null,
      sock => { if (!done) { done = true; clearTimeout(to); res(sock); } },
      ()   => { if (!done) { done = true; clearTimeout(to); res(null); } }
    ).catch(() => { if (!done) { done = true; clearTimeout(to); res(null); } });
  });
}

/* ── public API ──────────────────────────────────────────── */
async function setProfilePicture(tid, num, imagePath) {
  const sock = await ensureSock(tid, num);
  // Full-resolution, no crop — pass raw buffer directly
  const buf = fs.readFileSync(imagePath);
  await sock.updateProfilePicture(sock.user.id, buf);
}

async function getProfilePicture(tid, num) {
  const sock = await ensureSock(tid, num);
  return sock.profilePictureUrl(sock.user.id, 'image');
}

async function deleteProfilePicture(tid, num) {
  const sock = await ensureSock(tid, num);
  await sock.removeProfilePicture(sock.user.id);
}

async function disconnect(tid, num) {
  const s = getSock(tid, num);
  if (s) { await s.logout().catch(() => {}); active.delete(`${tid}:${num}`); }
}

module.exports = {
  createWhatsAppSession, setProfilePicture, getProfilePicture,
  deleteProfilePicture, disconnect, reconnect, getSock,
};
