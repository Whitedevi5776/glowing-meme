# WhatsApp Profile Picture Manager Bot

A premium Telegram bot for managing WhatsApp profile pictures without cropping, using `@rexxhayanasi/elaina-baileys`.

## Requirements

- Node.js 18+
- MongoDB (running locally or remote URI)
- Redis (for auto-change scheduler)

## Setup

```bash
# 1. Install dependencies
npm install

# 2. Copy and fill in your credentials
cp .env.example .env
nano .env

# 3. Start the bot
npm start
```

## .env Variables

| Key | Description |
|-----|-------------|
| `BOT_TOKEN` | Your Telegram bot token from @BotFather |
| `OWNER_ID` | Your Telegram user ID (from @userinfobot) |
| `MONGODB_URI` | MongoDB connection string |
| `REDIS_URL` | Redis URL (for auto-change scheduler) |
| `SESSION_SECRET` | A random secret string for session encryption |

## Features

- 📌 Pinterest/image search (HD images, 10 per page)
- 🔗 WhatsApp pairing via pairing code (no QR scan needed)
- 📱 Multiple WhatsApp accounts per user
- 🖼 Set profile picture — full HD, no cropping
- 📥 Get current profile picture
- ❌ Delete profile picture
- 🔄 Auto-change profile picture (hour or day based)
- ⏰ Persistent scheduler (survives bot restarts via BullMQ + Redis)
- 💬 Support ticket system with owner reply
- 👑 Owner panel (broadcast, stats, force-join, restart)

## Architecture

```
src/
├── app.js                  ← Entry point
├── commands/start.js       ← /start command
├── handlers/
│   ├── keyboards.js        ← All inline keyboard layouts
│   ├── callbackRouter.js   ← Routes button presses
│   ├── messageRouter.js    ← Routes text/image messages
│   ├── pinterestHandler.js
│   ├── pairingHandler.js
│   ├── accountHandler.js
│   └── supportHandler.js
├── services/
│   ├── whatsapp.js         ← Elaina Baileys wrapper
│   ├── pinterest.js        ← Image search
│   └── support.js          ← Ticket system
├── schedulers/
│   └── autoChange.js       ← BullMQ scheduler
├── database/
│   ├── connect.js
│   └── models.js           ← Mongoose schemas
├── middleware/
│   ├── auth.js             ← Owner check, force-join, upsertUser
│   ├── session.js          ← In-memory conversation state
│   └── rateLimit.js
├── owner/
│   └── ownerHandler.js
└── utils/
    ├── logger.js
    ├── helpers.js
    ├── encryption.js
    └── storage.js
```

## VPS Deployment

```bash
# Install MongoDB
# https://www.mongodb.com/docs/manual/installation/

# Install Redis
# https://redis.io/docs/getting-started/installation/

# Run with PM2 for process management
npm install -g pm2
pm2 start src/app.js --name wabot
pm2 save
pm2 startup
```
